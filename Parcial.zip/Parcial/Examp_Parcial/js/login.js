
$(document).ready(function () {
    
    checkLoggedInUser();
    
    $("#submitForm").on("click", function (e) {
        e.preventDefault();
        login();
    });
});


function checkLoggedInUser() {
    if (localStorage.getItem("token")) {
        
        redirectToUserPage();
    }
}


function login() {
    const $numero = $("#number");
    const $password = $("#password");

    if ($numero.val() === '' || $password.val() === '') {
        alert("Por favor, ingrese su numero y contraseña.");
        return;
    }

    const urlMain = "http://dev.desarrolloweb.com";
    const ajaxUrl = urlMain + "/json/login.json";

    $.ajax({
        type: "post",
        dataType: "json",
        url: ajaxUrl,
        data: {
            numero: $numero.val(),
            password: $password.val()
        },
        beforeSend: function () {
            
            $("#submitForm").addClass("loading");
        },
        success: function (response) {
            
            $("#submitForm").removeClass("loading");

            
            localStorage.setItem("token", response.token);

            
            if (response.userType === 1) {
                redirectToBancoMisiaPage();
            } else if (response.userType === 2) {
                redirectToUserPage();
            }
        },
        error: function (error) {
            alert("Error: no ingresas ya fuiste.");
        }
    });
}


function redirectToUserPage() {
    window.location.href = "dashboard_user.html";
}


function redirectToBancoMisiaPage() {
    window.location.href = "Banco-Misia.html";
}
