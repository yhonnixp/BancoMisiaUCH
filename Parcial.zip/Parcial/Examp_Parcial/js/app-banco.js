let cliente; 


fetch("dataClientes.json")
    .then(response => response.json())
    .then(data => {
        const clienteId = localStorage.getItem("clienteId");
        cliente = data.clientes.find(c => c.name === clienteId);
        const $user = document.getElementById("name");
        const $categoria = document.getElementById("categoria");
        const $direccion = document.getElementById("place"); 
        const $saldo = document.getElementById("saldo");

        $user.textContent = `Usuario: ${cliente.name}`;
        $categoria.textContent = `Categoría: ${cliente.categoria}`;
        $direccion.textContent = `Dirección: ${cliente.direccion}`;
        $saldo.textContent = `Saldo: ${cliente.saldo}`;
    })
    .catch(error => {
        console.error("Error al cargar los datos de clientes:", error);
    });

document.getElementById("transaccion").addEventListener("click", function() {
    if (cliente) {
        
        const monto = parseFloat(prompt("Ingrese el monto de la transacción:"));
        
        if (monto > 0 && monto <= parseFloat(cliente.saldo)) {
            generarTransaccion(monto);
        } else {
            alert("Monto inválido o saldo insuficiente.");
        }
    } else {
        console.error("No se pudo encontrar el cliente. Asegúrate de que los datos se hayan cargado correctamente.");
    }
});
function generarTransaccion(monto) {
    
}
