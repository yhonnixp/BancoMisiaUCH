document.addEventListener("DOMContentLoaded", function () {

    const transaccionId = localStorage.getItem("transaccionId");

    if (transaccionId) {
        cargarInformacionTransaccion(transaccionId);
    } else {
        alert("No se encontró información de la transacción.");
    }
});

function cargarInformacionTransaccion(transaccionId) {
    
    const nombreInput = document.getElementById("nombre");
    const montoInput = document.getElementById("monto");
    const fechaInput = document.getElementById("fecha");
    const codigoInput = document.getElementById("codigo");

    
    fetch("transacciones.json")
        .then(response => response.json())
        .then(data => {
            const transaccion = data.transacciones.find(t => t.id === transaccionId);

            if (transaccion) {
                nombreInput.value = transaccion.nombre;
                montoInput.value = transaccion.monto.toString(); 
                fechaInput.value = transaccion.fecha;
                codigoInput.value = transaccion.codigo;
            } else {
                alert("No se encontró información de la transacción.");
            }
        })
        .catch(error => {
            console.error("Error al cargar los datos de transacciones:", error);
        });
}
